# Multiplayer netcode (`src/net/`)

## Overview

This is the first multiplayer step the owner chose: **a game protocol, a server loop and a client, tested over a pretend network with delay, loss and reordering**, first over a pretend network and then **over real UDP sockets**. It runs the game's own player movement on a server and on up to four clients and keeps them in step. A **dedicated server program and a test bot** exist and play each other over real packets. **The running game does not use any of it yet** (`main.c` is untouched; there is no menu to host or join), so nothing about single-player can have changed.

What exists:

- a **wire format** (`net_wire`, `net_proto`): bytes in and out of a buffer with every access checked, and five messages (Hello, Welcome, Disconnect, Input, Snapshot);
- a **transport seam** (`net_transport.h`): the only thing the server and client know about the network;
- a **pretend network** (`net_loopback`): delay, jitter, loss, doubling, reordering, blackouts, with a fixed random generator so a run is the same every time;
- the **movement simulation** both ends share (`net_move_sim`): the real `PlayerStep`, jump and slide, from a rounded command;
- an **authoritative server** (`net_server`) and a **predicting client** (`net_client`).
- a **reliable-message layer** (`net_reliable`): whole messages, in order, exactly once, over any datagram path that loses, doubles and reorders;
- a **real transport** (`net_udp`): UDP sockets under the same seam, with the reliable layer on top, for a LAN or a server with an open port;
- a **server program and a test bot** (`src/server/`, `scripts/build_server.sh`), and a smoke test that runs them as separate processes.

### The architecture decision, and what it leaves open

The protocol, the server loop and the client logic are **C**, written against the small transport interface. There are now two transports behind it: the **pretend network** (tests) and **real UDP** (`net_udp`), which carries datagrams as UDP packets and reliable messages through a small reliable layer of our own (`net_reliable`). Reasons for plain UDP now: it needs nothing but the C library (so it builds on a phone in Termux, on Android and on a desktop), the sandbox can test it over real sockets, and the stated way to play (the same Wi-Fi, or a machine with an open port) needs no more. Its limits are real: **no encryption and no proof of who is who** (see Known limits), and a browser cannot use it at all (no UDP in a page).

The **Rust `mid-net` transports (native QUIC, the browser's WebTransport) are the upgrade path, not the first path**: QUIC gives encryption and a way through more networks, and WebTransport is the only way into a browser. They plug in behind the same interface through a C interface that has yet to be added to `mid_net.h` (today it has only the codec: encode and decode of two packet kinds, no connect, send or poll). The owner's CI results (mid-net 77 tests on rustc 1.99, the wasm one green) mean they build, so what is missing is that C interface, and a decision on the browser (WebTransport needs a secure page and a certificate the browser accepts; a WebSocket dev transport is the alternative). Nothing in the server or client changes when a transport is swapped.

## The protocol (`net_proto.h`)

Two channels, as a QUIC connection gives: **datagrams** that may be lost, doubled and reordered (Input, Snapshot), and a **reliable ordered** channel (Hello, Welcome, Disconnect). A packet starts `'T' 'B'` and a kind byte.

| Message | Direction | Channel | Size | What it carries |
|---|---|---|---|---|
| Hello | client to server | reliable | 17 B | protocol version, the chosen character id |
| Welcome | server to client | reliable | 27 B | version, tick rate, the player's id, the floor's seed and number, the server's tick, the spawn |
| Input | client to server | datagram | 40 B | the tick, the newest snapshot seen, and **four commands** (that tick and the three before it) |
| Snapshot | server to client | datagram | 71 to 125 B | the tick, whether the player has started, how early the newest command came, the owner's full movement state, up to three other players (rounded) |
| Disconnect | either | reliable | 4 B | a reason (normal, version, full, timeout, bad) |

A **command** (`NetCmd`, 7 bytes) is one tick of the player's wishes already rounded to what the wire carries (stick to a 127th, yaw to a 65536th of a turn, pitch to a 32767th of 89 degrees, eight buttons): **both ends run the game from the rounded command**, so the client's prediction and the server's simulation start from the same numbers. The buttons already include fire, use, swap and light, which this slice does not use yet.

The **owner's state** is sent as full floats (15 of them) and not rounded, because a rounded state could not be run on from; other players are told rounded millimetres.

**Decoding is strict**: wrong magic, an unknown kind, a short packet, a byte too many, a count over its limit, a NaN or infinity, an unknown flag bit, a character id that is not lowercase letters, digits and `_`, a player id out of range: all refused. Tested by cutting every message at every length, spoiling bytes, 300000 random and spoilt packets (what is accepted must re-encode to exactly the same bytes), and the whole test under AddressSanitizer and UndefinedBehaviorSanitizer with no finding.

**Bandwidth** at 30 snapshots a second: about 1.2 KB/s up and 2.1 to 3.8 KB/s down per client (full snapshots, no deltas yet).

## How it works

### The server (`net_server.c`)
It owns the floor (made from the seed, as every client makes it) and every player. **It never takes a position from a client**, only commands. Each tick (30 Hz, driven by the caller): for each player it takes the command that arrived for this tick and steps the player with `NetSim_Step`; then it sends every client a snapshot.

- A command carries the tick it is for. One **already past** is late (refused, counted); one **more than 20 ticks ahead** is refused (a flooded or forged clock); a **second command for a tick** is ignored (the first wins, so repeating a command does not move the player twice).
- A command that **did not arrive in time** is replaced by the last one for 5 ticks (one-off presses removed), then by standing still (the aim kept), then the client is dropped after 5 seconds of silence.
- The player is **not run until its first command arrives** (it starts at that command's tick), so the client and the server begin from the same state.
- It reports back **how early** the newest command came (`margin`, in ticks, negative when late). That is what the client tunes its clock by.
- **Limits:** at most 64 packets per client per poll (a flood waits, the tick is never held up), a stranger's packets counted and thrown away. **A connection that has not said Hello within 3 seconds is dropped**, so strangers cannot hold the four places.

### The client (`net_client.c`)
- **Prediction.** It runs its own player the moment the player acts, with the same `NetSim_Step`, keeps the last 64 ticks of commands and resulting states, and sends each command at once, repeated in the next three packets, so a lost packet is nearly always covered by the next (measured: 0.2% of commands missing at their tick at 20% loss).
- **Reconciliation.** A snapshot for tick T carries the server's state after tick T. The client compares it with its own record of tick T. Within 2 cm (and the same stamina, speed and slide state): nothing to do. Otherwise it **puts the server's state back and runs its own commands since again** to the present, so a correction is a change of the present and not a rubber band back in time. The jump that makes is **not shown**: the drawn position is the predicted one plus a difference that fades away (85% kept each tick), unless it is over two metres (a teleport, a respawn), which is shown as it is.
- **The clock.** Its tick count runs ahead of the server's (at first by the measured round trip plus 3 ticks) so a command is there before the server needs it. If the worst margin of the last 20 snapshots is below 1 it runs 5% faster, above 4 5% slower, until it is back in range (tested: a route that gets 8 times slower makes 48 commands late once, then none; when it is fast again the lead falls from 8 ticks to 6).
- **Other players** are drawn **100 ms in the past**, between the two snapshots that surround that time; with no newer snapshot they are held where they were last seen.

## Modules

### `net_wire.h` and `net_wire.c`
`NetW` and `NetR`: little-endian whatever the machine, every access checked. A writer that runs out of room, or a reader asked for more than is left, sets an error and goes on harmlessly; nothing is read or written outside the buffer. `NetR_Done` is true only when nothing went wrong and every byte was read.

### `net_proto.h` and `net_proto.c`
The messages above, `NetProto_Encode` and `NetProto_Decode`, and the command rounding (`NetCmd_Make`, `NetCmd_Move` which holds the length to 1 so a forged (127, 127) is no faster walk, `NetCmd_Yaw`, `NetCmd_Pitch`). The tick rate (30), the datagram limit (1200 bytes), the player limit (4) and the redundancy (4) are here.

### `net_transport.h`
`NetTransport`: send and receive of datagrams and of reliable messages, as function pointers, and an optional `close` (the connection is finished with: a real transport lets a Disconnect still in flight get out, then frees the connection). Nothing else of the network is known.

### `net_reliable.h` and `net_reliable.c`
Whole messages, in order, exactly once, over a path that loses, doubles and reorders packets. One `NetRel` per connection; it knows nothing of sockets (it hands the bytes to send to an emit function, is given the bytes that arrive, and is told the time), so it is tested over the pretend network with a made-up clock.

- **A window of 32 messages in flight**, each with a sequence number (16 bits, wrapping: tested over 70,000 messages), each resent with a growing wait until acknowledged. Messages are small (512 bytes at most): this carries the handshake and rare events, not a stream.
- **Acknowledgements are cumulative plus a bitmap of the next 32**, so a lost message does not make the ones after it wait (tested: with message 1 of 5 lost, only message 1 is sent again).
- **The wait** is the measured round trip plus four times its swing (only from messages sent once, so a resend does not confuse the measure), never under 40 ms, doubling each resend up to a second. After 12 sends of one message with no answer the connection is called dead (about 11 seconds on a dead path).
- **Flow control comes free**: a receiver that does not read holds one window and refuses the next; the sender stops at two windows and nothing is lost.
- It refuses a false acknowledgement (of messages never sent), an old copy is answered and not delivered again, and malformed packets are refused (tested with 200,000 random ones, under the sanitizers).

### `net_udp.h` and `net_udp.c`
The real network: `NetUdpHost`. A **server** listens on a UDP port (0 picks a free one) on every address of the machine and serves up to 8 connections from one socket; a **client** connects to an IPv4 address or name. Every packet starts with a **32-bit connection id** the client picks, then a kind byte (a datagram, or the reliable layer's data or acknowledgement), so one socket tells many players apart.

- **A connection opens** only when a server receives the *first reliable message of a connection* (a reliable data packet, sequence number 0, with something in it): the Hello. A random packet passes that about once in sixteen million; datagrams and later-numbered packets from a stranger open nothing. `NetUdpHost_Accept` hands the new connection to the game once.
- **A packet is accepted for a connection only from that connection's address** (a stranger who learns an id cannot speak for it; tested). Each connection keeps at most 32 datagrams waiting for the game to read (the rest are counted and dropped).
- **The transport's receive functions read the socket themselves**, so a game that only polls its transports needs nothing more than `Accept`.
- **Closing** lets the last message (a Disconnect) get out: the connection is kept up to two seconds until it is acknowledged, then freed. A connection is freed only when the game closes it (the server does when it drops a client or refuses a full house); there is no idle timeout of its own, so a connection a game forgets to close stays.
- `NetUdp_SetDebug(loss, double)` makes every packet sent be lost or sent twice with those chances: for tests and for trying the game on a bad network (`--loss` on the server and the bot).
- Only where `TOWER_NET_UDP` (platform.h: Android and desktop); elsewhere every function says "no network", so the web build links and does nothing. **A phone also needs the INTERNET permission in the Android manifest before it can use this; it is not added yet because nothing in the app uses the network yet.**

### The server program (`src/server/`, `scripts/build_server.sh`)
`tower_server [--port 7777] [--seed N] [--floor N] [--max-seconds N] [--loss PERCENT] [--quiet]`: one floor, up to four players, the loop of this document (accept, poll, tick at 30 Hz, a status line every 5 seconds), a summary line when it stops (Ctrl-C, or after `--max-seconds`), exit code 2 if it cannot listen. `tower_bot [host] [port] [--seconds N] [--name steve] [--loss PERCENT]`: a player with no screen that walks a fixed course and says how it went; exit 0 only if it was playing at the end, ran about the right number of ticks, and was never put back from scratch. **`bash scripts/build_server.sh` builds both** with the machine's `cc` (plain C, no raylib library, no window, `-O2` always: the player controller needs the optimiser for raymath's inline functions): `build/tower_server` and `build/tower_bot`. Their `main()` sits inside `TOWER_SERVER_MAIN` and `TOWER_BOT_MAIN`, because mray and the Android build compile every `.c` file and the game has a `main()` of its own. **No props yet** (see Known limits).

### `net_loopback.h` and `net_loopback.c`
A pretend link between two ends with time that only moves when the test says so. Per direction: latency, jitter (which reorders), loss, doubling. The reliable channel never loses and keeps order (a late message holds up the ones behind). A blackout loses datagrams and holds reliable messages until it ends. Datagrams over the limit are refused.

### `net_move_sim.h` and `net_move_sim.c`
`NetSim_Step` is the movement of `SimTick` in `main.c` (slide, sprint, `PlayerStep`, jump, in that order) from a `NetCmd`; `NetSim_Capture` and `NetSim_Apply` take and put back the movement state; `NetSim_Error` says how far apart two are (position, plus anything that would make the sprint differ a second later). **When `SimTick` moves out of `main.c`, this is what it replaces.**

### `net_server.h` and `net_server.c`, `net_client.h` and `net_client.c`
As above.

## Tests: `tests/net_headless.c`

97 checks, each with its reason in its name: the wire; the protocol (round trips to the same bytes, every refusal, command rounding, the fuzz); the pretend network (latency, 20% loss gives about a fifth lost, doubling, reordering, reliable in order, blackouts, same seed same network); the handshake (ids, the same floor on both ends, versions both ways, a full server); **prediction with no delay** (no correction after the start, the client's record of every tick within a ten-thousandth of a metre of the server's, and proof that the script really jumps, sprints and slides on the server); **a bad network** (100 ms round trip, 5% loss: no command missing at its tick, no correction); **a very bad one** (200 ms, 20% loss, 5% doubled: 0.2% missing, no restart from scratch); **reconciliation** (a shove the client could not know about is corrected and the client agrees again; the drawn player glides while the predicted one jumps; a 6 m shove is not glided; a stamina-only difference is corrected); **commands not to be trusted** (before Hello, from the far future, ten copies, late, forged full speed, a flood, junk); **other players** (within 2 cm of the truth at the time shown under 5% loss and jitter, no jumps, held in a half-second blackout, accurate again after it); **leaving and going quiet** (goodbye, a freed slot, a client that goes silent stops where it is and is dropped after 5 s, a client that hears nothing closes); **the clock lead** (adapts both ways).

**Mutation tests (36).** Each rule was broken on purpose and the tests had to fail: every wire check; every decode refusal; no loss, no order, no blackout, no size limit in the pretend network; every server rule (version, late, far future, doubled, flood limit, Hello first, repeat for ever, timeout, **a connection that never says Hello**, margin sign, run before the first command); and on the client never correcting, correcting without replaying, no smoothing, glide over a huge jump, no clock adjustment, no repeated commands, no interpolation, no 100 ms delay, a stamina difference not noticed, and the server ignoring jump or sprint. **Four survived at first and were fixed in the tests:** the server ignoring jumps or sprint (both ends share the movement code, so breaking it on both keeps them in agreement; the tests now prove the script jumps, sprints and slides), and a stamina difference (a big one also changes the speed and so shows up as a position error; a 5-point one isolates the rule).

## Tests: the reliable layer, the real network, the programs

### `tests/net_rel_headless.c` (28 checks)
Both ends of the reliable layer joined by the pretend network. A clean path (200 messages, no resends, the round trip measured right); **a path that loses 30%, doubles 10% and reorders** (500 messages in order, once each; both ends sending at once, 300 each way); **sequence numbers going round** (70,000 messages); one lost message among several (only it is sent again, the rest held back until it arrives); the window (exactly 32 taken, one byte over the size limit or none refused, a message too big for the reader's buffer dropped not cut); a receiver that does not read (the sender stops at two windows, and everything arrives in order once it reads); a dead path (given up on after a bounded number of resends, not at once); packets that are not its own (an old copy, a false acknowledgement even with messages in flight, empty, unknown, short, wrongly sized, 200,000 random). **Mutation tests (13)**, each caught: an old copy delivered again, selective acknowledgements ignored, no round-trip measure, no window limit, a dead path never noticed, sequence numbers that do not wrap, a false acknowledgement believed, an oversize message copied, a short acknowledgement accepted, a message beyond the window stored, nothing ever resent, no cap on the wait. **One survived at first**: a false acknowledgement is undone by the catch-up loop when nothing is in flight, so the test now has three messages in flight.

### `tests/net_udp_headless.c` (34 checks, about 15 seconds in real time)
A server and clients in one process over **real UDP on 127.0.0.1**. The transport by itself (a port of its own choosing; a second server cannot take it; a connection opens only on the first reliable message and is announced once; reliable and datagram both ways; size limits; **100 datagrams at an unread connection keep 32 and count the rest**). A server and two clients for a few seconds (playing within a second, 0.4 ms round trip, 144 ticks in 4.8 s, no corrections, no restarts). **15% of every packet lost and 5% doubled**, both ways: Hello and Welcome still get through, play goes on, 0 of 121 commands missing at their tick. A full server (a fifth client is told, reliably, over UDP); goodbye and the connection freed; **a stranger's junk** (200 random packets and two that are not a connection: counted, thrown away, nothing opened); **a stranger using a live connection's id from another address**; a reliable packet that is not a first one; sixteen strangers each opening a connection (no more than the slots, nobody in the game); and a client with nobody to answer (gives up after five seconds, says why). **Mutation tests (6)**: any reliable packet opening a connection, the address not checked, no limit on a connection's queue, a connection announced again and again, two servers sharing a port, and a connection that never says Hello keeping its place; all caught (the last by `net_headless.c`, where that rule is tested).

### `tests/server_smoke.sh` (about 15 seconds)
Builds `tower_server` and `tower_bot` with `scripts/build_server.sh` and runs them **as separate programs**: one server, two bots, **10% of every packet lost on the way out**. Passes when both bots finish playing (exit 0: playing at the end, about 30 ticks a second, no restart) and the server saw both players. (5 s each: 149 ticks, 0 corrections.)

The whole suite, with the real-time tests, takes about 90 seconds. Under AddressSanitizer and UndefinedBehaviorSanitizer all of `net_headless`, `net_rel_headless` and `net_udp_headless` ran with no finding.

## Not verified

- **Cross-machine determinism.** Prediction matched to a ten-thousandth of a metre because client and server ran the same binary on one machine. A phone (ARM) and a server (x86 or ARM) may differ in the last bits of a float (fused multiply-add, the maths library). The 2 cm tolerance and the reconciliation are built for that, but how often they fire between real devices is unknown until a phone talks to a server.
- **Only the loopback address.** The real-UDP tests and the smoke test ran on this machine's `127.0.0.1`, where there is no loss, delay or reordering of its own (the loss in them is injected). What a real Wi-Fi does (reordering, bursts of loss, a phone that sleeps its radio), and a second device, are untried. Frame pacing on a phone (a frame that takes 100 ms, the app in the background) is not tested either; the client runs at most 5 ticks in one update and drops the rest.
- **Termux and Android.** The server and bot are plain C99 and POSIX sockets and should build with Termux's `clang` through `scripts/build_server.sh`; nobody has tried. The Android game build compiles the transport but cannot use it until the INTERNET permission is in the manifest.
- **The Rust transports** (native QUIC, the browser's WebTransport) are not connected; see "what comes next".
- Nothing here has been run in the game or on a screen.

## Known limits (what this slice is not)

- **Movement only.** Shots, hits, enemies, the swarm, doors, stairs, the stair clock, pickups, the inventory, the flashlight and health are all still `main.c`'s. They need `SimTick` and its state out of `main.c` into a simulation that has no window, with the monsters, projectiles and pickups (module-global today, so one simulation per process) as parts of it. That is the next step and the owner's earlier choice.
- **Props.** The player's movement collides with the floor's props (`CheckObstacleCollision`, a module-global list). The tests have no props. A real server and client must build the same props from the floor seed; if they do not, prediction will be wrong near them.
- One floor per server; changing floors is not handled. Players do not collide with one another and all start at the same place. No health or death in the netcode yet.
- Snapshots are whole every tick: no deltas, no interest management, 4 players at most.
- The client's aim is trusted as sent (fine for co-op, not for a competitive mode).
- A returning network after a gap shows the other player jumping to where they now are (they did move); there is no catch-up glide and no extrapolation.
- Only the physical movement state is compared when reconciling; the camera's eye height and head bob are not.
- **No encryption and no sign-in on the UDP transport**: everything is plain text, and the connection id is a random number, not a secret (anyone on the path who sees one can learn it; the address check stops a casual stranger, not someone who can also forge the address). Fine for a LAN and for trying things, not for the open internet. QUIC is the answer; a sign-in is for the lobby.
- **No reach beyond the local network by itself**: a server on a phone behind mobile data (carrier NAT) cannot be reached; same Wi-Fi works, and a machine with an open UDP port works. IPv4 only. No keep-alive packet: a connection is kept alive by the 30 Hz of play, and a client sitting in a menu would be dropped after five seconds of silence.
- A UDP connection is freed only when the game closes it; a game that never does leaks the slot (the server always does).

## What comes next

1. **Move `SimTick` and its state out of `main.c`** into a simulation with no window (commands in, events out), with a replay test at two frame rates; this makes the whole game runnable by the server and replaces `net_move_sim`. It also brings the props with it, so server and client collide with the same ones.
2. **The client in the game**: a menu to host or join (the host runs the server program, or the game starts the server loop itself), `NetClient_Update` in the frame loop, the other players drawn, the INTERNET permission in the manifest.
3. **A real-network trial**: the server on one device, the game or the bot on another, over the owner's Wi-Fi; the first time the numbers in "Not verified" get tested (cross-device determinism, reordering, the phone).
4. **The Rust transports behind the same seam** (QUIC for encryption and reach; WebTransport for the browser): the C interface in `mid_net.h` (connect, send, poll), a `NetTransport` over it, built by CI. The owner has not chosen between WebTransport and a WebSocket dev transport for the browser.

## Fixes and Problems

- **The player controller needs the props function.** Linking it for the first time here failed on `CheckObstacleCollision`; the test supplies "no props" as the movement tests do.
- **A test measured the wrong thing.** The reconciliation test shoved the player 1.7 m, which became 2.4 m once the commands since were run again, over the client's two-metre "do not glide" limit, so it saw no glide. Now a 1 m shove tests the glide and a 6 m one tests the snap.
- **The half-second blackout test's window included the moment the network came back**, so it saw the (correct) jump to where the other player now was. The window ends before that, and a second check says they are accurate again afterwards.
- **The slide never happened in the first script** (a wall stopped the sprint, and a slide needs 2 m/s); found only because a test counted slides. The script now tries more than once.
- A statically allocated pool of link ends was replaced by two ends inside each link before it could bite a test that makes many links.
- **Junk could open a connection.** The first real-UDP test of a stranger's packets failed: about 1 in 256 random packets has the reliable-data kind byte, and the server made a connection for any such packet, which then held a player place for up to five seconds. Now a connection opens only for the first reliable message of one (sequence number 0), and a connection that has not said Hello in 3 seconds is dropped.
- **A resend wait that grew to four seconds** made a dead path take 36 s to notice (and a handshake over a lossy link slow); it is now capped at one second (about 11 s to give up).
- **`SO_REUSEADDR` removed**: on UDP it would have let a second server silently share the first one's port. The test that tries it crashed under the mutation, which is how it was confirmed to matter.
- Two tests were wrong rather than the code: one expected a receiver that never reads to stop the sender at one window (it is two), and one stopped the instant the last message arrived, before its acknowledgement could.
